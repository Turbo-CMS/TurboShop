/* Data for table t_articles */
TRUNCATE TABLE `t_articles`;

/* Data for table t_articles_categories */
TRUNCATE TABLE `t_articles_categories`;

/* Data for table t_banners */
TRUNCATE TABLE `t_banners`;
INSERT INTO `t_banners` (`id`, `group_id`, `name`, `position`, `visible`, `show_all_pages`, `categories`, `pages`, `brands`, `articles_categories`) VALUES
('1','1','Main slider','1','1','0','0','1','0','0');

/* Data for table t_banners_images */
TRUNCATE TABLE `t_banners_images`;
INSERT INTO `t_banners_images` (`id`, `banner_id`, `name`, `alt`, `title`, `description`, `url`, `button`, `image`, `position`, `visible`) VALUES
('1','1','Google Home Smart Speaker','Google Home Smart Speaker','Google Home Smart Speaker','starting at $129.00','/','Shop Now','hero-slide01.png','1','1'),
('2','1','Modern Powerful Vaio Laptop','Modern Powerful Vaio Laptop','Modern Powerful Vaio Laptop','for only $1,459.99','/','Shop Now','hero-slide02.png','2','1'),
('3','1','Wireless Beats Studio by Dr.Dre','Wireless Beats Studio by Dr.Dre','Wireless Beats Studio by Dr.Dre','starting at $349.50','/','Shop Now','hero-slide03.png','3','1');

/* Data for table t_blog */
TRUNCATE TABLE `t_blog`;

/* Data for table t_brands */
TRUNCATE TABLE `t_brands`;

/* Data for table t_callbacks */
TRUNCATE TABLE `t_callbacks`;

/* Data for table t_categories */
TRUNCATE TABLE `t_categories`;

/* Data for table t_categories_features */
TRUNCATE TABLE `t_categories_features`;

/* Data for table t_comments */
TRUNCATE TABLE `t_comments`;

/* Data for table t_coupons */
TRUNCATE TABLE `t_coupons`;

/* Data for table t_currencies */
TRUNCATE TABLE `t_currencies`;
INSERT INTO `t_currencies` (`id`, `name`, `sign`, `code`, `rate_from`, `rate_to`, `cents`, `position`, `enabled`) VALUES
('1','USD','$','USD','8.98','8.98','0','1','1'),
('2','UAH','₴','UAH','30.00','1.00','0','2','1'),
('3','EUR','€','EUR','0.96','1.00','0','3','1');

/* Data for table t_delivery */
TRUNCATE TABLE `t_delivery`;
INSERT INTO `t_delivery` (`id`, `name`, `description`, `free_from`, `price`, `enabled`, `position`, `separate_payment`) VALUES
('1','Courier delivery in the city','<p>Courier delivery is carried out by the service of the carrier companies of the city. Your order will be shipped the day after the order. Delivery takes from 1 to 3 days.</p>','200.00','20.00','1','1',null),
('2','Pickup','<p>Convenient, free and fast way to receive an order.</p>','0.00','0.00','1','2',null);

/* Data for table t_delivery_payment */
TRUNCATE TABLE `t_delivery_payment`;
INSERT INTO `t_delivery_payment` (`delivery_id`, `payment_method_id`) VALUES
('1','2'),
('1','3'),
('1','4'),
('1','5'),
('2','2'),
('2','3'),
('2','4'),
('2','5');

/* Data for table t_faq */
TRUNCATE TABLE `t_faq`;

/* Data for table t_features */
TRUNCATE TABLE `t_features`;

/* Data for table t_feedbacks */
TRUNCATE TABLE `t_feedbacks`;

/* Data for table t_files */
TRUNCATE TABLE `t_files`;

/* Data for table t_groups */
TRUNCATE TABLE `t_groups`;

/* Data for table t_images */
TRUNCATE TABLE `t_images`;

/* Data for table t_labels */
TRUNCATE TABLE `t_labels`;

/* Data for table t_lang_articles */
TRUNCATE TABLE `t_lang_articles`;

/* Data for table t_lang_articles_categories */
TRUNCATE TABLE `t_lang_articles_categories`;

/* Data for table t_lang_banners_images */
TRUNCATE TABLE `t_lang_banners_images`;
INSERT INTO `t_lang_banners_images` (`lang_id`, `lang_label`, `banner_image_id`, `name`, `alt`, `title`, `description`, `url`, `button`) VALUES
('1','','1','Google Home Smart Speaker','Google Home Smart Speaker','Google Home Smart Speaker','от $129.00','/','Купить'),
('2','','1','Google Home Smart Speaker','Google Home Smart Speaker','Google Home Smart Speaker','starting at $129.00','/','Shop Now'),
('3','','1','Google Home Smart Speaker','Google Home Smart Speaker','Google Home Smart Speaker','від $129,00','/','Купити'),
('1','','2','Modern Powerful Vaio Laptop','Modern Powerful Vaio Laptop','Modern Powerful Vaio Laptop','всего за $1459,99','/','Купить'),
('2','','2','Modern Powerful Vaio Laptop','Modern Powerful Vaio Laptop','Modern Powerful Vaio Laptop','for only $1,459.99','/','Shop Now'),
('3','','2','Modern Powerful Vaio Laptop','Modern Powerful Vaio Laptop','Modern Powerful Vaio Laptop','всього за $1459,99','/','Купити'),
('1','','3','Wireless Beats Studio by Dr.Dre','Wireless Beats Studio by Dr.Dre','Wireless Beats Studio by Dr.Dre','от $349,50','/','Купить'),
('2','','3','Wireless Beats Studio by Dr.Dre','Wireless Beats Studio by Dr.Dre','Wireless Beats Studio by Dr.Dre','starting at $349.50','/','Shop Now'),
('3','','3','Wireless Beats Studio by Dr.Dre','Wireless Beats Studio by Dr.Dre','Wireless Beats Studio by Dr.Dre','від $349,50','/','Купити');

/* Data for table t_lang_blog */
TRUNCATE TABLE `t_lang_blog`;

/* Data for table t_lang_brands */
TRUNCATE TABLE `t_lang_brands`;

/* Data for table t_lang_categories */
TRUNCATE TABLE `t_lang_categories`;

/* Data for table t_lang_currencies */
TRUNCATE TABLE `t_lang_currencies`;
INSERT INTO `t_lang_currencies` (`lang_id`, `lang_label`, `currency_id`, `name`, `sign`) VALUES
('1','','1','USD','$'),
('2','','1','USD','$'),
('3','','1','USD','$'),
('1','','2','UAH','₴'),
('2','','2','UAH','₴'),
('3','','2','UAH','₴'),
('2','','3','EUR','€'),
('3','','3','EUR','€'),
('1','','3','EUR','€');

/* Data for table t_lang_delivery */
TRUNCATE TABLE `t_lang_delivery`;
INSERT INTO `t_lang_delivery` (`lang_id`, `lang_label`, `delivery_id`, `name`, `description`) VALUES
('1','','1','Курьерская доставка по городу','<p>Курьерская доставка осуществляется службой компаний-перевозчиков города. Ваш заказ будет отправлен на следующий день после заказа. Доставка занимает от 1 до 3 дней.</p>'),
('2','','1','Courier delivery in the city','<p>Courier delivery is carried out by the service of the carrier companies of the city. Your order will be shipped the day after the order. Delivery takes from 1 to 3 days.</p>'),
('1','','2','Самовывоз','<p>Удобный, бесплатный и быстрый способ получения заказа.</p>'),
('3','','1','Кур\'єрська доставка по місту','<p>Кур\'єрська доставка здійснюється службою компаній-перевізників міста. Ваше замовлення буде відправлений на наступний день після замовлення. Доставка займає від 1 до 3 днів.</p>'),
('2','','2','Pickup','<p>Convenient, free and fast way to receive an order.</p>'),
('3','','2','Самовивіз','<p>Зручний, безкоштовний і швидкий спосіб отримання замовлення.</p>');

/* Data for table t_lang_faq */
TRUNCATE TABLE `t_lang_faq`;

/* Data for table t_lang_features */
TRUNCATE TABLE `t_lang_features`;

/* Data for table t_lang_files */
TRUNCATE TABLE `t_lang_files`;

/* Data for table t_lang_pages */
TRUNCATE TABLE `t_lang_pages`;
INSERT INTO `t_lang_pages` (`lang_id`, `lang_label`, `page_id`, `name`, `meta_title`, `meta_description`, `meta_keywords`, `body`, `header`) VALUES
('1','','1','Главная','Главная','Этот магазин является демонстрацией скрипта интернет-магазина  Turbo CMS. Все материалы на этом сайте присутствуют исключительно в демонстрационных целях. ','Главная','<p>Этот магазин является демонстрацией скрипта интернет-магазина <a href=\"https://turbo-cms.com/\">Turbo</a>. Все материалы на этом сайте присутствуют исключительно в демонстрационных целях.&nbsp;</p>','Главная'),
('2','','1','Home','Home','This store is a demonstration of the script for the online store Turbo CMS. All materials on this site are for demonstration purposes only.','Home','<p>This store is a demonstration of the script for the online store <a href=\"https://turbo-cms.com/\"> Turbo </a>. All materials on this site are for demonstration purposes only.</p>','Home'),
('3','','1','Головна','Головна','Цей магазин є демонстрацією скрипта інтернет-магазину Turbo CMS . Всі матеріали на цьому сайті присутні виключно в демонстраційних цілях.','Головна','<p>Цей магазин є демонстрацією скрипта інтернет-магазину <a href=\"https://turbo-cms.com/\"> Turbo </a>. Всі матеріали на цьому сайті присутні виключно в демонстраційних цілях.</p>','Головна'),
('1','','2','Все товары','Все товары','Все товары','Все товары','','Все товары'),
('2','','2','All products','All products','All products','All products','','All products'),
('3','','2','Всі товари','Всі товари','Всі товари','Всі товари','','Всі товари'),
('1','','3','404','Страница не найдена','Страница не найдена','Страница не найдена','<p>Страница не найдена</p>','Страница не найдена'),
('2','','3','404','Page not found','Page not found','Page not found','<p>Page not found</p>','Page not found'),
('3','','3','404','Сторінка не знайдена','Сторінка не знайдена','Сторінка не знайдена','<p>Сторінка не знайдена</p>','Сторінка не знайдена'),
('1','','4','Карта сайта','Карта сайта','Карта сайта','Карта сайта','','Карта сайта'),
('2','','4','Sitemap','Sitemap','Sitemap','Sitemap','','Sitemap'),
('3','','4','Карта сайту','Карта сайту','Карта сайту','Карта сайту','','Карта сайту'),
('1','','5','Новинки','Новинки','Новинки','Новинки','','Новинки'),
('2','','5','New','New','New','New','','New'),
('3','','5','Новинки','Новинки','Новинки','Новинки','','Новинки'),
('1','','6','Рекомендуемые','Рекомендуемые','Рекомендуемые','Рекомендуемые','','Рекомендуемые'),
('2','','6','Featured','Featured','Featured','Featured','','Featured'),
('3','','6','Рекомендовані','Рекомендовані','Рекомендовані','Рекомендовані','','Рекомендовані'),
('1','','7','Распродажа','Распродажа','Распродажа','Распродажа','','Распродажа'),
('2','','7','Sale','Sale','Sale','Sale','','Sale'),
('3','','7','Розпродаж','Розпродаж','Розпродаж','Розпродаж','','Розпродаж'),
('1','','8','Хиты','Хиты','Хиты','Хиты','','Хиты'),
('2','','8','Hit','Hit','Hit','Hit','','Hit'),
('3','','8','Хіти','Хіти','Хіти','Хіти','','Хіти'),
('1','','9','Избранное','Избранное','Избранное','Избранное','','Избранное'),
('2','','9','Wishlist','Wishlist','Wishlist','Wishlist','','Wishlist'),
('3','','9','Обране','Обране','Обране','Обране','','Обране'),
('1','','10','Сравнение','Сравнение','Сравнение','Сравнение','','Сравнение'),
('2','','10','Compare','Compare','Compare','Compare','','Compare'),
('3','','10','Порівняння','Порівняння','Порівняння','Порівняння','','Порівняння'),
('1','','11','Оплата','Оплата','Оплата','Оплата','<h2>Наличными курьеру</h2>\r\n<p>Вы можете оплатить заказ курьеру в гривнах непосредственно в момент доставки. Курьерская доставка осуществляется по Киеву на следующий день после принятия заказа.</p>\r\n<h2>Банковская карта</h2>\r\n<p>Оплата банковской картой Visa или MasterCard.</p>\r\n<h2>Через терминал</h2>\r\n<p>Оплатите наличными через многочисленные терминалы в любом городе. Можно заплатить и с банковской карты через многие банкоматы.&nbsp;</p>\r\n<h2>Со счета мобильного телефона</h2>\r\n<p>Оплата со счета мобильного телефона.</p>\r\n<h2>Квитанция</h2>\r\n<p>Вы можете распечатать квитанцию и оплатить её в любом отделении банка.</p>\r\n<h2>PayPal</h2>\r\n<p>Совершайте покупки безопасно, без раскрытия информации о своей кредитной карте. PayPal защитит вас, если возникнут проблемы с покупкой.</p>\r\n<h2>Оплата через Интеркассу</h2>\r\n<p>Это удобный в использовании сервис, подключение к которому позволит Интернет-магазинам, веб-сайтам и прочим торговым площадкам принимать все возможные формы оплаты в максимально короткие сроки.</p>\r\n<h2>Оплата картой через Liqpay.com</h2>\r\n<p>Благодаря своей открытости и универсальности LiqPAY стремительно интегрируется со многими платежными системами и платформами и становится стандартом платежных операций.</p>','Оплата'),
('2','','11','Payment','Payment','Payment\r\n','Payment','<h2>Cash</h2>\r\n<p>You can pay the courier directly in rubles at the time of delivery. The Express delivery within New York next day after order acceptance.</p>\r\n<h2>PayPal</h2>\r\n<p>Make purchases&nbsp;safely,&nbsp;without disclosing information&nbsp;about your credit card.&nbsp;PayPal&nbsp;will protect&nbsp;you if&nbsp;problems occur&nbsp;with purchase.</p>','Payment'),
('3','','11','Оплата','Оплата','Оплата\r\n','Оплата','<h2>Готівкою кур\'єру</h2>\r\n<p>Ви можете оплатити замовлення кур\'єру в гривнях безпосередньо в момент доставки. Кур\'єрська доставка здійснюється по Києву на наступний день після прийняття замовлення.</p>\r\n<h2>Банківська картка</h2>\r\n<p>Оплата банківською картою Visa або MasterCard.</p>\r\n<h2>PayPal</h2>\r\n<p>Робіть покупки безпечно, без розкриття інформації про свою кредитну картку. PayPal захистить вас, якщо виникнуть проблеми з покупкою.</p>\r\n<h2>Оплата через Інтеркаса</h2>\r\n<p>Це зручний у використанні сервіс, підключення до якого дозволить Інтернет-магазинам, веб-сайтам та іншим торговим майданчикам приймати всі можливі форми оплати в максимально короткі терміни.</p>\r\n<h2>Оплата карткою через Liqpay</h2>\r\n<p>Завдяки своїй відкритості та універсальності LiqPAY стрімко інтегрується з багатьма платіжними системами і платформами і стає стандартом платіжних операцій.</p>\r\n<h2>Готівкою в офісі Нова Пошта</h2>\r\n<p>При доставці замовлення системою Нова Пошта, ви зможете оплатити замовлення в їхньому офісі безпосередньо в момент отримання товарів.</p>','Оплата'),
('1','','12','Доставка','Доставка','Доставка','Доставка','<h2>Курьерская доставка по Киеву</h2>\r\n<p>Курьерская доставка осуществляется на следующий день после оформления заказа, если товар есть в наличии. Курьерская доставка осуществляется в пределах Киева ежедневно с 10.00 до 21.00. Заказ на сумму свыше 1000 гривен доставляется бесплатно.<br /><br />Стоимость бесплатной доставки раcсчитывается от суммы заказа с учтенной скидкой. В случае если сумма заказа после применения скидки менее 1000 грн, осуществляется платная доставка.<br /><br />При сумме заказа менее 1000 грн стоимость доставки составляет от 100 грн.</p>\r\n<h2>Самовывоз</h2>\r\n<p>Удобный,&nbsp;бесплатный и быстрый способ получения заказа.<br />Адрес офиса: <span class=\"JLqJ4b ChMk0b\" data-language-for-alternatives=\"ru\" data-language-to-translate-into=\"uk\" data-phrase-index=\"0\" data-number-of-phrases=\"2\"><span class=\"Q4iAWc\">Киев, ул.</span></span> <span class=\"JLqJ4b ChMk0b\" data-language-for-alternatives=\"ru\" data-language-to-translate-into=\"uk\" data-phrase-index=\"1\" data-number-of-phrases=\"2\"><span class=\"Q4iAWc\">Глубочицкая, 32б</span></span>.</p>\r\n<h2>Доставка с помощью предприятия &laquo;Новая Почта&raquo;</h2>\r\n<p>Удобный и быстрый способ доставки в города Украины. Посылка доставляется в офис &laquo;Новая Почта&raquo; в вашем городе. Для получения необходимо предъявить паспорт и номер грузовой декларации (сообщит наш менеджер после отправки). Посылку желательно получить в течение 24 часов с момента прихода груза, иначе компания &laquo;Новая Почта&raquo; может взыскать с вас дополнительную оплату за хранение. Срок доставки и стоимость вы можете рассчитать на сайте компании.</p>\r\n<h2>Наложенным платежом</h2>\r\n<p>При доставке заказа наложенным платежом с помощью &laquo;Новая Почта&raquo;, вы сможете оплатить заказ непосредственно в момент получения товаров.</p>','Доставка'),
('2','','12','Delivery','Delivery','Delivery','Delivery','<h2>Shipping within New York</h2>\r\n<p>Courier delivery is made&nbsp;the next day&nbsp;after ordering,&nbsp;if the item is in stock.&nbsp;Courier delivery is made&nbsp;within the New York&nbsp;daily from&nbsp;10.00 to&nbsp;21.00.&nbsp;For orders&nbsp;more than $300 delivered free of charge.<br /><br />Cost&nbsp;free delivery is calculated&nbsp;from&nbsp;the total order&nbsp;with&nbsp;the discount&nbsp;taken into account.&nbsp;If the order amount&nbsp;after applying the discount&nbsp;less than $300,&nbsp;is&nbsp;a paid service.</p>\r\n<p>For orders&nbsp;less than $300,&nbsp;the&nbsp;delivery&nbsp;cost is $50.</p>\r\n<h2>Store pickup</h2>\r\n<p>Convenient, free&nbsp;and&nbsp;fast way of receiving your order.</p>\r\n<p>Office address:&nbsp;41 West 40th Street New York, NY</p>\r\n<h2>C.O.D (Cash On Delivery)</h2>\r\n<p>On delivery order cash on delivery through \"mail of USA\", you will be able to pay for the order at the time goods are received.</p>','Delivery'),
('3','','12','Доставка','Доставка','Доставка','Доставка','<h2>Кур\'єрська доставка по Києву</h2>\r\n<p>Кур\'єрська доставка здійснюється на наступний день після оформлення замовлення, якщо товар є в наявності. Кур\'єрська доставка здійснюється в межах Києва; щодня з 10.00 до 21.00. Замовлення на суму понад 300 грн доставляється безкоштовно. Вартість безкоштовної доставки Розраховувати від суми замовлення з врахованої знижкою. У разі якщо сума замовлення після застосування знижки менш 300 грн, здійснюється платна доставка. При сумі замовлення менше 300 грн вартість доставки складає від 50 грн.</p>\r\n<h2>Самовивіз</h2>\r\n<p>Зручний, безкоштовний і швидкий спосіб отримання замовлення. Місцезнаходження компанії: Київ, вул. Глибочицька, 32б.</p>\r\n<h2>Доставка за допомогою підприємства &laquo;Нова Пошта&raquo;</h2>\r\n<p>Зручний і швидкий спосіб доставки у великі міста України. Посилка доставляється в офіс &laquo;Нова пошта&raquo; у Вашому місті. Для отримання необхідно пред\'явити паспорт і номер вантажної декларації (повідомить наш менеджер після відправки). Посилку бажано отримати протягом 24 годин з моменту приходу вантажу, інакше компанія &laquo;Нова Пошта&raquo; може стягнути з Вас додаткову оплату за зберігання. Термін доставки і вартість Ви можете розрахувати на сайті компанії.</p>\r\n<h2>Післяплата</h2>\r\n<p>При доставці замовлення післяплатою за допомогою &laquo;Нова Пошта&raquo;, ви зможете оплатити замовлення безпосередньо в момент отримання товарів.</p>','Доставка'),
('1','','13','Блог','Блог','','Блог','','Блог'),
('2','','13','Blog','Blog','','Blog','','Blog'),
('3','','13','Блог','Блог','','Блог','','Блог'),
('1','','14','Контакты','Контакты','Контакты','Контакты','<p><span class=\"JLqJ4b ChMk0b\" data-language-for-alternatives=\"ru\" data-language-to-translate-into=\"uk\" data-phrase-index=\"0\" data-number-of-phrases=\"2\"><span class=\"Q4iAWc\">Киев, ул.</span></span> <span class=\"JLqJ4b ChMk0b\" data-language-for-alternatives=\"ru\" data-language-to-translate-into=\"uk\" data-phrase-index=\"1\" data-number-of-phrases=\"2\"><span class=\"Q4iAWc\">Глубочицкая, </span></span>32б, 02000</p>\r\n<p>Телефон: (095) 545-54-54</p>\r\n<p><iframe style=\"border: 0;\" tabindex=\"0\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1269.9307677918514!2d30.49195294945491!3d50.46230305803582!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x84a28f327eb7dc52!2z0JDRgNC10L3QtNCwINC-0YTQuNGB!5e0!3m2!1sru!2sua!4v1609513285692!5m2!1sru!2sua\" width=\"100%\" height=\"450\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\" aria-hidden=\"false\"></iframe></p>','Контакты'),
('2','','14','Contacts','Contacts','Contacts','Contacts','<p>41 West 40th Street New York, NY</p>\r\n<p>Phone: (210) 876-5432</p>\r\n<p><iframe style=\"border: 0;\" tabindex=\"0\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4399.518506840664!2d-73.97964170435294!3d40.75394620817656!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259aa94a61b4f%3A0x8ebce7fe1262c134!2zNDEgVyA0MHRoIFN0LCBOZXcgWW9yaywgTlkgMTAwMTgsINCh0KjQkA!5e0!3m2!1sru!2sua!4v1609512981791!5m2!1sru!2sua\" width=\"100%\" height=\"450\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\" aria-hidden=\"false\"></iframe></p>','Contacts'),
('3','','14','Контакти','Контакти','Контакти','Контакти','<p>Київ, вул. Глибочицька, 32б, 02000</p>\r\n<p>Телефон: (095) 545-54-54</p>\r\n<p><iframe style=\"border: 0;\" tabindex=\"0\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1269.9307677918514!2d30.49195294945491!3d50.46230305803582!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x84a28f327eb7dc52!2z0JDRgNC10L3QtNCwINC-0YTQuNGB!5e0!3m2!1sru!2sua!4v1609513285692!5m2!1sru!2sua\" width=\"100%\" height=\"450\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\" aria-hidden=\"false\"></iframe></p>','Контакти'),
('1','','15','Бренды','Бренды','','Бренды','','Бренды'),
('2','','15','Brands','Brands','','Brands','','Brands'),
('3','','15','Бренди','Бренди','','Бренди','','Бренди'),
('1','','16','Статьи','Статьи','','Статьи','','Статьи'),
('2','','16','Articles','Articles','','Articles','','Articles'),
('3','','16','Статті','Статті','','Статті','','Статті'),
('1','','17','Каталог','Каталог','','Каталог','','Каталог'),
('2','','17','Catalog','Catalog','','Catalog','','Catalog'),
('3','','17','Каталог','Каталог','','Каталог','','Каталог'),
('1','','18','Поиск','Поиск','','Поиск','','Поиск'),
('2','','18','Search','Search','','Search','','Search'),
('3','','18','Пошук','Пошук','','Пошук','','Пошук'),
('1','','25','FAQ','FAQ','FAQ','FAQ','','FAQ'),
('2','','25','FAQ','FAQ','FAQ','FAQ','','FAQ'),
('3','','25','FAQ','FAQ','FAQ','FAQ','','FAQ'),
('1','','26','Отзывы','Отзывы','Отзывы','Отзывы','','Отзывы'),
('2','','26','Reviews','Reviews','Reviews','Reviews','','Reviews'),
('3','','26','Відгуки','Відгуки','Відгуки','Відгуки','','Відгуки');

/* Data for table t_lang_payment_methods */
TRUNCATE TABLE `t_lang_payment_methods`;
INSERT INTO `t_lang_payment_methods` (`lang_id`, `lang_label`, `payment_id`, `name`, `description`) VALUES
('1','','2','Оплата картой через Liqpay','<p>LiqPay &mdash; платежная система, позволяющая проводить оплату банковскими картами MasterСard и VISA, а также наличными через терминалы самообслуживания Приватбанка. Оплата возможна после входа в аккаунт через номер мобильного телефона.</p>'),
('2','','2','Liqpay','<p>LiqPay is a payment system that allows you to pay with MasterCard and VISA credit cards, as well as in cash through Privatbank self-service terminals. Payment is possible after entering the account through a mobile phone number.</p>'),
('1','','3','Оплата наличными курьеру','<p>Если вы не хотите предварительно оплачивать заказ, у вас есть возможность рассчитаться с курьером наличными в момент получения посылки. Чтобы процесс был максимально комфортным и для вас, и для курьера, рекомендуем заранее подготовить нужную сумму.</p>'),
('3','','2','Оплата карткою через Liqpay','<p>LiqPay - платіжна система, що дозволяє проводити оплату банківськими картами MasterСard і VISA, а також готівкою через термінали самообслуговування Приватбанку. Оплата можлива після входу в обліковий запис через номер мобільного телефону.</p>'),
('2','','3','Cash payment to courier','<p>If you do not want to pre-pay the order, you have the opportunity to pay the courier in cash at the time of receipt of the parcel. To make the process as comfortable as possible for both you and the courier, we recommend that you prepare the required amount in advance.</p>'),
('1','','4','PayPal','<p>Совершайте покупки безопасно, без раскрытия информации о своей кредитной карте. PayPal защитит вас, если возникнут проблемы с покупкой.</p>'),
('3','','3','Оплата готівкою кур\'єру','<p>Якщо ви не хочете попередньо оплачувати замовлення, у вас є можливість розрахуватися з кур\'єром готівкою в момент отримання посилки. Щоб процес був максимально комфортним і для вас, і для кур\'єра, рекомендуємо заздалегідь підготувати потрібну суму.</p>'),
('2','','4','PayPal','<p>PayPal is a global e-commerce business allowing payments and money transfers to be made through the Internet. Online money transfers serve as electronic alternatives to paying with traditional paper methods, such as checks and money orders.</p>'),
('3','','4','PayPal','<p>Робіть покупки безпечно, без розкриття інформації про свою кредитну картку. PayPal захистить вас, якщо виникнуть проблеми з покупкою.</p>'),
('1','','5','Оплата через WayForPay','<p>WayForPay &mdash; это онлайн-сервис с оплатой через банковские карты платежных систем VISA и MasterCard. Доступные методы платежа: Приват 24, терминал, сервис обслуживает прием платежей через систему Bitcoin.</p>'),
('2','','5','WayForPay','<p>WayForPay is an online service with payment through bank cards of VISA and MasterCard payment systems. Available payment methods: Privat 24, terminal, the service serves the acceptance of payments through the Bitcoin system.</p>'),
('3','','5','Оплата через WayForPay','<p>WayForPay - це онлайн-сервіс з оплатою через банківські картки платіжних систем VISA і MasterCard. Доступні методи платежу: Приват 24, термінал, сервіс обслуговує прийом платежів через систему Bitcoin.</p>');

/* Data for table t_lang_products */
TRUNCATE TABLE `t_lang_products`;

/* Data for table t_lang_variants */
TRUNCATE TABLE `t_lang_variants`;

/* Data for table t_languages */
TRUNCATE TABLE `t_languages`;
INSERT INTO `t_languages` (`id`, `name`, `label`, `is_default`, `enabled`, `position`) VALUES
('1','Russian','ru','0','1','3'),
('2','English','en','0','1','1'),
('3','Ukrainian','ua','0','1','2');

/* Data for table t_menu */
TRUNCATE TABLE `t_menu`;
INSERT INTO `t_menu` (`id`, `name`, `position`) VALUES
('1','Main menu','1'),
('2','Other pages','2'),
('3','Information','3');

/* Data for table t_options */
TRUNCATE TABLE `t_options`;

/* Data for table t_orders */
TRUNCATE TABLE `t_orders`;

/* Data for table t_orders_labels */
TRUNCATE TABLE `t_orders_labels`;

/* Data for table t_pages */
TRUNCATE TABLE `t_pages`;
INSERT INTO `t_pages` (`id`, `parent_id`, `url`, `name`, `meta_title`, `meta_description`, `meta_keywords`, `body`, `menu_id`, `position`, `visible`, `header`, `last_modified`) VALUES
('1','0','','Home','Home','This store is a demonstration of the script for the online store Turbo CMS. All materials on this site are for demonstration purposes only.','Home','<p>This store is a demonstration of the script for the online store <a href=\"https://turbo-cms.com/\"> Turbo </a>. All materials on this site are for demonstration purposes only.</p>','2','1','1','Home','2022-04-20 19:00:31'),
('2','0','all-products','All products','All products','All products','All products','','2','2','1','All products','2022-04-20 18:59:39'),
('3','0','404','404','Page not found','Page not found','Page not found','<p>Page not found</p>','2','3','1','Page not found','2022-04-20 18:59:08'),
('4','0','sitemap','Sitemap','Sitemap','Sitemap','Sitemap','','2','18','1','Sitemap','2022-04-20 19:00:40'),
('5','0','new','New','New','New','New','','2','5','1','New','2022-04-20 18:58:20'),
('6','0','featured','Featured','Featured','Featured','Featured','','2','6','1','Featured','2022-04-20 18:58:02'),
('7','0','sale','Sale','Sale','Sale','Sale','','2','7','1','Sale','2022-04-20 18:57:40'),
('8','0','hit','Hit','Hit','Hit','Hit','','2','8','1','Hit','2022-04-20 18:57:18'),
('9','0','wishlist','Wishlist','Wishlist','Wishlist','Wishlist','','2','9','1','Wishlist','2022-04-20 18:56:52'),
('10','0','compare','Compare','Compare','Compare','Compare','','2','10','1','Compare','2022-04-20 18:56:30'),
('11','0','payments','Payment','Payment','Payment\r\n','Payment','<h2>Cash</h2>\r\n<p>You can pay the courier directly in rubles at the time of delivery. The Express delivery within New York next day after order acceptance.</p>\r\n<h2>PayPal</h2>\r\n<p>Make purchases&nbsp;safely,&nbsp;without disclosing information&nbsp;about your credit card.&nbsp;PayPal&nbsp;will protect&nbsp;you if&nbsp;problems occur&nbsp;with purchase.</p>','1','11','1','Payment','2022-04-20 18:50:08'),
('12','0','delivery','Delivery','Delivery','Delivery','Delivery','<h2>Shipping within New York</h2>\r\n<p>Courier delivery is made&nbsp;the next day&nbsp;after ordering,&nbsp;if the item is in stock.&nbsp;Courier delivery is made&nbsp;within the New York&nbsp;daily from&nbsp;10.00 to&nbsp;21.00.&nbsp;For orders&nbsp;more than $300 delivered free of charge.<br /><br />Cost&nbsp;free delivery is calculated&nbsp;from&nbsp;the total order&nbsp;with&nbsp;the discount&nbsp;taken into account.&nbsp;If the order amount&nbsp;after applying the discount&nbsp;less than $300,&nbsp;is&nbsp;a paid service.</p>\r\n<p>For orders&nbsp;less than $300,&nbsp;the&nbsp;delivery&nbsp;cost is $50.</p>\r\n<h2>Store pickup</h2>\r\n<p>Convenient, free&nbsp;and&nbsp;fast way of receiving your order.</p>\r\n<p>Office address:&nbsp;41 West 40th Street New York, NY</p>\r\n<h2>C.O.D (Cash On Delivery)</h2>\r\n<p>On delivery order cash on delivery through \"mail of USA\", you will be able to pay for the order at the time goods are received.</p>','1','12','1','Delivery','2022-04-20 18:54:50'),
('13','0','blog','Blog','Blog','','Blog','','1','25','1','Blog','2022-04-20 19:00:55'),
('14','0','contact','Contacts','Contacts','Contacts','Contacts','<p>41 West 40th Street New York, NY</p>\r\n<p>Phone: (210) 876-5432</p>\r\n<p><iframe style=\"border: 0;\" tabindex=\"0\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4399.518506840664!2d-73.97964170435294!3d40.75394620817656!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259aa94a61b4f%3A0x8ebce7fe1262c134!2zNDEgVyA0MHRoIFN0LCBOZXcgWW9yaywgTlkgMTAwMTgsINCh0KjQkA!5e0!3m2!1sru!2sua!4v1609512981791!5m2!1sru!2sua\" width=\"100%\" height=\"450\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\" aria-hidden=\"false\"></iframe></p>','1','26','1','Contacts','2022-04-20 19:01:02'),
('15','0','brands','Brands','Brands','','Brands','','3','13','1','Brands','2022-04-20 19:01:15'),
('16','0','articles','Articles','Articles','','Articles','','3','15','1','Articles','2022-04-20 19:01:21'),
('17','0','catalog','Catalog','Catalog','','Catalog','','3','4','1','Catalog','2022-04-20 19:01:10'),
('18','0','search','Search','Search','','Search','','3','16','1','Search','2022-04-20 19:01:27'),
('25','0','faq','FAQ','FAQ','FAQ','FAQ','','3','17','1','FAQ','2022-04-20 19:01:32'),
('26','0','reviews','Reviews','Reviews','Reviews','Reviews','','1','14','1','Reviews','2022-04-20 19:00:47');

/* Data for table t_payment_methods */
TRUNCATE TABLE `t_payment_methods`;
INSERT INTO `t_payment_methods` (`id`, `module`, `name`, `description`, `currency_id`, `settings`, `enabled`, `position`) VALUES
('2','Liqpay','Liqpay','<p>LiqPay is a payment system that allows you to pay with MasterCard and VISA credit cards, as well as in cash through Privatbank self-service terminals. Payment is possible after entering the account through a mobile phone number.</p>','1','a:2:{s:17:\"liqpay_public_key\";s:0:\"\";s:18:\"liqpay_private_key\";s:0:\"\";}','1','3'),
('3','null','Cash payment to courier','<p>If you do not want to pre-pay the order, you have the opportunity to pay the courier in cash at the time of receipt of the parcel. To make the process as comfortable as possible for both you and the courier, we recommend that you prepare the required amount in advance.</p>','1','N;','1','2'),
('4','Paypal','PayPal','<p>PayPal is a global e-commerce business allowing payments and money transfers to be made through the Internet. Online money transfers serve as electronic alternatives to paying with traditional paper methods, such as checks and money orders.</p>','1','a:2:{s:8:\"business\";s:0:\"\";s:4:\"mode\";s:4:\"real\";}','1','4'),
('5','WayForPay','WayForPay','<p>WayForPay is an online service with payment through bank cards of VISA and MasterCard payment systems. Available payment methods: Privat 24, terminal, the service serves the acceptance of payments through the Bitcoin system.</p>','1','a:3:{s:18:\"wayforpay_merchant\";s:0:\"\";s:19:\"wayforpay_secretkey\";s:0:\"\";s:18:\"wayforpay_language\";s:2:\"EN\";}','1','5');

/* Data for table t_products */
TRUNCATE TABLE `t_products`;

/* Data for table t_products_categories */
TRUNCATE TABLE `t_products_categories`;

/* Data for table t_products_videos */
TRUNCATE TABLE `t_products_videos`;

/* Data for table t_purchases */
TRUNCATE TABLE `t_purchases`;

/* Data for table t_related_products */
TRUNCATE TABLE `t_related_products`;

/* Data for table t_seo */
TRUNCATE TABLE `t_seo`;
INSERT INTO `t_seo` (`setting_id`, `name`, `value`) VALUES
('1','am_url','www.example.com'),
('2','am_name','Online store Turbo Shop'),
('3','am_phone','(123) 456-78-90'),
('4','am_email','me@example.com'),
('5','category_meta_title',''),
('6','category_brand_meta_title',''),
('7','brand_meta_title',''),
('8','product_meta_title',''),
('9','page_meta_title',''),
('10','post_meta_title',''),
('11','category_article_meta_title',''),
('12','article_meta_title',''),
('13','category_meta_keywords',''),
('14','category_brand_meta_keywords',''),
('15','brand_meta_keywords',''),
('16','product_meta_keywords',''),
('17','page_meta_keywords',''),
('18','post_meta_keywords',''),
('19','category_article_meta_keywords',''),
('20','article_meta_keywords',''),
('21','category_meta_description',''),
('22','category_brand_meta_description',''),
('23','brand_meta_description',''),
('24','product_meta_description',''),
('25','page_meta_description',''),
('26','post_meta_description',''),
('27','category_article_meta_description',''),
('28','article_meta_description',''),
('29','seo_automation','on');

/* Data for table t_seo_lang */
TRUNCATE TABLE `t_seo_lang`;
INSERT INTO `t_seo_lang` (`name`, `lang_id`, `value`) VALUES
('am_email','1','me@example.com'),
('am_name','1','Интернет-магазин Turbo Shop'),
('am_phone','1','(123) 456-78-90'),
('am_url','1','www.example.com'),
('article_meta_description','1',''),
('article_meta_keywords','1',''),
('article_meta_title','1',''),
('brand_meta_description','1',''),
('brand_meta_keywords','1',''),
('brand_meta_title','1',''),
('category_article_meta_description','1',''),
('category_article_meta_keywords','1',''),
('category_article_meta_title','1',''),
('category_brand_meta_description','1',''),
('category_brand_meta_keywords','1',''),
('category_brand_meta_title','1',''),
('category_meta_description','1',''),
('category_meta_keywords','1',''),
('category_meta_title','1',''),
('page_meta_description','1',''),
('page_meta_keywords','1',''),
('page_meta_title','1',''),
('post_meta_description','1',''),
('post_meta_keywords','1',''),
('post_meta_title','1',''),
('product_meta_description','1',''),
('product_meta_keywords','1',''),
('product_meta_title','1',''),
('am_email','2','me@example.com'),
('am_name','2','Online store Turbo Shop'),
('am_phone','2','(123) 456-78-90'),
('am_url','2','www.example.com'),
('article_meta_description','2',''),
('article_meta_keywords','2',''),
('article_meta_title','2',''),
('brand_meta_description','2',''),
('brand_meta_keywords','2',''),
('brand_meta_title','2',''),
('category_article_meta_description','2',''),
('category_article_meta_keywords','2',''),
('category_article_meta_title','2',''),
('category_brand_meta_description','2',''),
('category_brand_meta_keywords','2',''),
('category_brand_meta_title','2',''),
('category_meta_description','2',''),
('category_meta_keywords','2',''),
('category_meta_title','2',''),
('page_meta_description','2',''),
('page_meta_keywords','2',''),
('page_meta_title','2',''),
('post_meta_description','2',''),
('post_meta_keywords','2',''),
('post_meta_title','2',''),
('product_meta_description','2',''),
('product_meta_keywords','2',''),
('product_meta_title','2',''),
('am_email','3','me@example.com'),
('am_name','3','Інтернет-магазин Turbo Shop'),
('am_phone','3','(123) 456-78-90'),
('am_url','3','www.example.com'),
('article_meta_description','3',''),
('article_meta_keywords','3',''),
('article_meta_title','3',''),
('brand_meta_description','3',''),
('brand_meta_keywords','3',''),
('brand_meta_title','3',''),
('category_article_meta_description','3',''),
('category_article_meta_keywords','3',''),
('category_article_meta_title','3',''),
('category_brand_meta_description','3',''),
('category_brand_meta_keywords','3',''),
('category_brand_meta_title','3',''),
('category_meta_description','3',''),
('category_meta_keywords','3',''),
('category_meta_title','3',''),
('page_meta_description','3',''),
('page_meta_keywords','3',''),
('page_meta_title','3',''),
('post_meta_description','3',''),
('post_meta_keywords','3',''),
('post_meta_title','3',''),
('product_meta_description','3',''),
('product_meta_keywords','3',''),
('product_meta_title','3','');

/* Data for table t_settings */
TRUNCATE TABLE `t_settings`;
INSERT INTO `t_settings` (`setting_id`, `name`, `value`) VALUES
('1','theme','default'),
('2','date_format','d.m.Y'),
('3','admin_email','me@example.com'),
('4','site_work','on'),
('5','captcha_product','1'),
('6','captcha_post','1'),
('7','captcha_cart','1'),
('8','captcha_article','1'),
('9','captcha_register','1'),
('10','captcha_feedback','1'),
('11','captcha_callback','1'),
('12','captcha_fastorder','1'),
('13','order_email','me@example.com'),
('14','comment_email','me@example.com'),
('15','notify_from_email','me@example.com'),
('16','email_lang','en'),
('17','decimals_point','.'),
('18','thousands_separator',' '),
('19','products_num','9'),
('20','products_num_admin','20'),
('21','max_order_amount','50'),
('22','lang','en'),
('23','articles_num','15'),
('24','articles_num_admin','15'),
('25','blog_num','15'),
('26','blog_num_admin','15'),
('27','smart_resize',''),
('28','webp_support','1'),
('29','category_count','1'),
('30','watermark_offset_x','50'),
('31','watermark_offset_y','50'),
('32','watermark_transparency','50'),
('33','images_sharpen','50'),
('34','export_export_not_in_stock','1'),
('35','export_available_for_retail_store','1'),
('36','export_available_for_reservation','1'),
('37','export_short_description',''),
('38','export_has_manufacturer_warranty','1'),
('39','export_has_seller_warranty','1'),
('40','export_no_export_without_price','1'),
('41','export_sales_notes',''),
('42','image_sizes','55x55|110x110|90x90|240x240|570x570|800x800w|300x300|95x95|330x300|500x500|100x100|900x350|35x35|400x300|300x120|130x130|150x150|170x170|116x116|75x23|40x40|700x700|750x750|750x300|750x467|700x467|250x120|50x50|700x300|120x120|966x378|800x600|960x375|1024x768w|45x45|200x100|80x80|90x60|30x30|180x100|800x400|550x440'),
('43','comments_tree_blog','on'),
('44','comments_tree_articles','on'),
('45','lastModifyPosts','2022-08-11 00:34:59'),
('46','chat_viber','123456789'),
('47','chat_whats_app','123456789'),
('48','chat_telegram','test'),
('49','chat_facebook','test'),
('50','features_num_admin','25'),
('51','comments_tree_review','on'),
('52','captcha_review','1'),
('53','comments_tree_reviews','on'),
('54','lastModifyFAQ','2022-08-11 03:10:00'),
('56','lastModifyReviews','2021-09-30 08:01:02'),
('58','comments_tree_products','on'),
('59','cached','0'),
('60','cache_type','0'),
('61','cache_time','86400'),
('63','counters',''),
('64','watermark_enable','1');

/* Data for table t_settings_lang */
TRUNCATE TABLE `t_settings_lang`;
INSERT INTO `t_settings_lang` (`name`, `lang_id`, `value`) VALUES
('company_name','1','Turbo CMS'),
('notify_from_name','1','Администратор'),
('site_name','1','Интернет-магазин Turbo Shop'),
('units','1','шт'),
('weight_units','1','г'),
('company_name','2','Turbo CMS'),
('notify_from_name','2','Admin'),
('site_name','2','Online store Turbo Shop'),
('units','2','pc'),
('weight_units','2','g'),
('company_name','3','Turbo CMS'),
('notify_from_name','3','Адмін'),
('site_name','3','Інтернет-магазин Turbo Shop'),
('units','3','шт'),
('weight_units','3','г');

/* Data for table t_subscribes */
TRUNCATE TABLE `t_subscribes`;

/* Data for table t_translations */
TRUNCATE TABLE `t_translations`;
INSERT INTO `t_translations` (`id`, `template`, `in_config`, `label`, `lang_ru`, `lang_en`, `lang_ua`) VALUES
('39','','0','callback','Заказать звонок','Request a call','Замовити дзвінок'),
('40','','0','contact_details','Киев, ул. Глубочицкая, 32б','41 West 40th Street New York, NY','Київ, вул. Глибочицька, 32б'),
('6','','0','bloge','Блоге','entries','Блогу'),
('41','','0','phone_number','(903) 782-82-82','(210) 876-5432','(095) 545-54-54'),
('42','','0','close','Закрыть','Close','Закрити'),
('43','','0','catalog','Каталог','Catalog','Каталог'),
('9','','0','aktsionnye_tovary','Акционные товары','Action goods','Акційні товари'),
('37','','0','login','Вход','Login','Вхід'),
('22','','0','votes','голосов','votes','голосів'),
('21','','0','vote','голос','vote','голос'),
('38','','0','logout','Выйти','Logout','Вихід'),
('16','','0','add_cart','Купить','Add To Cart','Купити'),
('17','','0','added_cart','В корзине','Added To Cart','В кошику'),
('18','','0','more_details','Далее','More details','Далі'),
('19','','0','not_available','Нет в наличии','Not available','Немає в наявності'),
('20','','0','In_stock','В наличии','In stock','В наявності'),
('23','','0','of_vote','голоса','vote','голоси'),
('24','','0','add_to_wishlist','В избранное','Add to wishlist','У обране'),
('25','','0','added_to_wishlist','В избранном','Added to wishlist','В обраному'),
('26','','0','add_to_compare','В сравнение','Add to compare','До порівняння'),
('27','','0','added_to_compare','В сравнении ','Added to compare','В порівнянні'),
('28','','0','delete','Удалить','Delete','Видалити'),
('29','','0','featured_products','Рекомендуемые товары','Featured products','Рекомендовані товари'),
('30','','0','badge_new','Новинка','New','Новинка'),
('31','','0','badge_hit','Хит','Hit','Хіт'),
('32','','0','badge_sale','Акция','Sale','Акція'),
('33','','0','new_arrivals','Новинки','New arrivals','Новинки'),
('34','','0','sale','Акционные товары','Sale','Акційні товари'),
('35','','0','index_cart','Корзина','Cart','Кошик'),
('36','','0','registration','Регистрация','Registration','Реєстрація'),
('44','','0','currency','Валюта','Currency','Валюта'),
('45','','0','product_search','Поиск товара...','Product search...','Пошук товару...'),
('46','','0','all_products','Все товары','All products','Усі товари'),
('47','','0','all_brands','Все бренды','All Brands','Всі бренди'),
('48','','0','viewed_products','Просмотренные товары','Viewed products','Переглянуті товари'),
('49','','0','index_blog','Блог','Blog','Блог'),
('50','','0','enter_your_email','Оставьте свой e-mail','Enter your Email','Залиште свій e-mail'),
('51','','0','main_description','Этот магазин является демонстрацией скрипта интернет-магазина Turbo CMS. Все материалы на этом сайте присутствуют исключительно в демонстрационных целях.','This store is a demo of the script of the Turbo CMS online store. All materials on this site are present for demonstration purposes only.','Цей магазин є демонстрацією скрипта інтернет-магазину Turbo CMS. Всі матеріали на цьому сайті присутні виключно в демонстраційних цілях.'),
('53','','0','about_shop','О магазине','About Shop','Про магазин'),
('54','','0','information','Информация','Information','Інформація'),
('55','','0','contacts','Контакты','Contacts','Контакти'),
('56','','0','request_a_call','Заказать звонок','Request a call','Замовити дзвінок'),
('57','','0','your_phone_number','Оставьте свой номер телефона','Leave your phone number','Залиште свій номер телефону'),
('58','','0','enter_your_name','Введите имя','Enter your name','Введіть ім\'я'),
('59','','0','enter_phone_number','Введите номер телефона','Enter your phone number','Введіть номер телефону'),
('60','','0','captcha_incorrect','Неверно введена капча','Captcha entered incorrectly','Невірно введена капча'),
('61','','0','enter_the_address','Введите адрес','Enter the address','Введіть адресу'),
('62','','0','enter_captcha','Введите капчу','Enter captcha','Введіть капчу'),
('63','','0','name','Имя','Name','Ім\'я'),
('64','','0','enter_a_comment','Введите комментарий','Enter a comment','Введіть коментар'),
('80','','0','buy_one_click','Купить в один клик','Buy in one click','Купити в один клік'),
('66','','0','home','Главная','Home','Головна'),
('67','','0','password','Пароль','Password','Пароль'),
('68','','0','forgot_password','Забыли пароль?','Forgot your password','Забули пароль?'),
('69','','0','enter_password','Введите пароль','Enter password','Введіть пароль'),
('70','','0','phone','Телефон','Phone','Телефон'),
('71','','0','address','Адрес','Address','Адреса'),
('72','','0','email_already_registered','Пользователь с таким email уже зарегистрирован','User with this email is already registered','Користувач з таким email вже зареєстрований'),
('73','','0','send','Отправить','Send','Надіслати'),
('74','','0','short_description','Краткое описание','Short description','Короткий опис'),
('75','','0','end_promotion','До конца акции осталось:','Until the end of the promotion is left:','До кінця акції залишилося:'),
('76','','0','colour','Цвет','Colour','Колір'),
('77','','0','size','Размер','Size','Розмір'),
('78','','0','sku','Артикул','SKU','Артикул'),
('81','','0','description','Описание','Description','Опис'),
('82','','0','feature','Характиристики','Feature','Характеристики'),
('83','','0','comments_global','Комментарии','Comments','Коментарі'),
('84','','0','awaiting_moderation','ожидает модерации','awaiting moderation','очікує модерації'),
('85','','0','comment_1','Комментарий','Comment','Коментар'),
('86','','0','comment_on','Комментировать','Comment on','Коментувати'),
('87','','0','no_comments','Пока нет комментариев','No comments','Поки немає коментарів'),
('88','','0','related_products','Сопутствующие товары','Related products','Супутні товари'),
('89','','0','email_order_title','Ваш заказ №','Your Order No.','Ваше замовлення №'),
('90','','0','email_order_on_total','на сумму','for the amount','на суму'),
('92','','0','badge_featured','Рекомендуем','featured','Рекомендуємо'),
('111','','0','reply','Ответить','Reply','Відповісти'),
('96','','0','files_global','Файлы','Files','Файли'),
('97','','0','videos_global','Видео','Video','Відео'),
('98','','0','wishlist_no_products','Список избранного пуст','Wishlist is empty','Список обраного порожній'),
('99','','0','sort_by','Сортировать по','Sort by','Сортувати за'),
('100','','0','default','Умолчанию','Default','Замовчуванням'),
('101','','0','name_a_z','По имени от А до Я','By name from A to Z','На ім\'я від А до Я'),
('102','','0','name_z_a','По имени от Я до А','By name from Z to A','На ім\'я від Я до А'),
('103','','0','cheap_expensive','От дешевых к дорогим','Cheap to expensive','Від дешевих до дорогих'),
('104','','0','expensive_cheap','От дорогих к дешевым','From expensive to cheap','Від дорогих до дешевих'),
('105','','0','by_rating','По рейтингу','By rating','за рейтингом'),
('106','','0','no_products_found','Товары не найдены','No products found','Товари не знайдені'),
('107','','0','search','Поиск','Search','Пошук'),
('108','','0','nothing_found','Ничего не найдено','Nothing found','Нічого не знайдено'),
('109','','0','enter_search_query','Введите поисковый запрос','Enter your search term','Введіть пошуковий запит'),
('110','','0','site_search','Поиск по сайту','Site search','Пошук по сайту'),
('112','','0','at','в','at','в'),
('113','','0','popular','Популярные','Popular','Популярні'),
('114','','0','in_order','По порядку','In order','По порядку'),
('115','','0','comment_2','Комментариев','Comments','Коментарів'),
('116','','0','table_of_contents','Содержание','Table of Contents','Зміст'),
('117','','0','already_voted','Вы уже голосовали!','You have already voted!','Ви вже голосували!'),
('118','','0','vote_counted','Спасибо! Ваш голос учтен.','Thank you! Your vote has been counted.','Спасибі! Ваш голос враховано.'),
('119','','0','message_sent','Сообщение отправлено','Message sent','Повідомлення відправлено'),
('120','','0','success_subscribe','Вы были успешно подписаны','You have been successfully subscribed','Ви були успішно підписані'),
('121','','0','already_subscribe','Вы уже подписаны','You are already subscribed','Ви вже підписані'),
('122','','0','subscribe_to','Подписаться','Subscribe to','Підписатися'),
('123','','0','search_article','Поиск статьи...','Search article...','Пошук статті...'),
('124','','0','sitemap','Карта сайта','Sitemap','Карта сайту'),
('125','','0','index_articles','Статьи','Articles','Статті'),
('126','','0','index_products','Продукты','Products','Продукти'),
('127','','0','sort_date','По дате','Date','За датою'),
('128','','0','search_blog','Поиск в блоге...','Search blog...','Пошук в блозі...'),
('129','','0','filter_by_price','Фильтр по цене','Filter by price','Фільтр по ціні'),
('130','','0','apply','Применить','Apply','Застосувати'),
('131','','0','reset','Сбросить','Reset','Скинути'),
('132','','0','index_brands','Бренды','Brands','Бренди'),
('133','','0','index_feedback','Обратная связь','Feedback','Зворотній зв\'язок'),
('134','','0','feedback_message_sent','ваше сообщение отправлено.','your message has been sent.','ваше повідомлення відправлено.'),
('135','','0','enter_your_message','Введите сообщение','Enter your message','Введіть повідомлення'),
('136','','0','message','Сообщение','Message','Повідомлення'),
('137','','0','password_reminder','Напоминание пароля','Password reminder','Нагадування пароля'),
('138','','0','email_sent','Вам отправлено письмо','An email has been sent to you','Вам надіслано листа'),
('139','','0','user_not_found','Пользователь не найден','User is not found','Користувач не знайдений'),
('140','','0','password_recovery_email','отправлено письмо для восстановления пароля.','password recovery email has been sent.','відправлено лист для відновлення пароля.'),
('141','','0','enter_email_registration','Введите email, который вы указывали при регистрации','Enter the email you provided during registration','Введіть email, який ви вказали при реєстрації'),
('142','','0','wrong_login_password','Неверный логин или пароль','Wrong login or password','Невірний логін або пароль'),
('143','','0','not_activated','Ваш аккаунт еще не активирован.','Your account has not been activated yet.','Ваш аккаунт ще не був активований.'),
('144','','0','no_post_found','Записи не найдены','No post found','Публікації не знайдено'),
('145','','0','your_discount','Ваша скидка','Your discount','Ваша знижка'),
('146','','0','change_password','Изменить пароль','Change Password','Змінити пароль'),
('147','','0','save','Сохранить','Save','Зберегти'),
('148','','0','your_orders','Ваши заказы','Your orders','Ваші заказы'),
('149','','0','index_order','Заказ №','Order №','Заказ №'),
('150','','0','paid','оплачен','paid','оплачений'),
('151','','0','waiting_processing','ждет обработки','waiting for processing','чекає обробки'),
('152','','0','in_processing','в обработке','in processing','в обробці'),
('153','','0','completed','выполнен','completed','виконаний'),
('154','','0','site_closed','Сайт закрыт на техническое обслуживание','Site closed for maintenance','Сайт зараз закритий на технічне обслуговування'),
('155','','0','apologize','Приносим извинения за неудобство, но в данный момент сайт находится на техническом обслуживание. Скоро мы вернемся online!','We apologize for the inconvenience, but the site is currently undergoing maintenance. We\'ll be back online soon!','Приносимо вибачення за незручність, але в даний момент сайт знаходиться на технічному обслуговуванні. Скоро ми повернемося online!'),
('156','','0','forward','вперед','forward','вперед'),
('157','','0','back','назад','back','назад'),
('158','','0','all_at_once','все сразу','all at once','всі відразу'),
('159','','0','order_page','Страница заказа','Order page','Сторінка замовлення'),
('160','','0','accepted','принят','accepted','прийнятий'),
('161','','0','general_name','Название','Name','Назва'),
('162','','0','general_price','Цена','Price','Ціна'),
('163','','0','number','Количество','Number','Кількість'),
('164','','0','sum','Сумма','Sum','Сума'),
('165','','0','discount','Скидка','Discount','Знижка'),
('166','','0','coupon','Купон','Coupon','Купон'),
('167','','0','total','Итого','Total','Разом'),
('168','','0','choose_payment','Выбрать другой способ оплаты','Choose another payment method','Вибрати інший спосіб оплати'),
('169','','0','payment_method','Способ оплаты','Payment method','Спосіб оплати'),
('170','','0','select_payment_method','Выберите способ оплаты','Select a Payment Method','Оберіть спосіб оплати\r\n'),
('171','','0','order_details','Детали заказа','Order details','Деталі замовлення'),
('172','','0','order_date','Дата заказа','Order date','Дата замовлення'),
('173','','0','delivery_address','Адрес доставки','Delivery address','Адреса доставки'),
('174','','0','finish_the_order','Закончить заказ','Finish the order','Закінчити замовлення'),
('175','','0','to_pay','К оплате','To pay','До оплати'),
('176','','0','to_pay_small','к оплате','to pay','до оплати'),
('177','','0','proceed_to_checkout','Перейти к оплате','Proceed to checkout','Перейти до оплати'),
('178','','0','global_cart','Корзина','Cart','Кошик'),
('180','','0','coupon_is_invalid','Купон недействителен','Coupon is invalid','Купон недійсний'),
('181','','0','coupon_valid','действует для заказов от','valid for orders from','діє для замовлень від'),
('182','','0','enter_coupon_code','Введите код купона...','Enter coupon code...','Введіть код купона...'),
('183','','0','apply_coupon','Применить купон','Apply coupon','Застосувати купон'),
('184','','0','select_delivery_method','Выберите способ доставки','Select delivery method','Виберіть спосіб доставки'),
('185','','0','free','бесплатно','free','безкоштовно'),
('186','','0','address_recipient','Адрес получателя','Address of the recipient','Адреса отримувача'),
('187','','0','general_full_name','ФИО','Full name','ПІБ'),
('188','','0','checkout','Оформить заказ','Checkout','Оформити замовлення\r\n'),
('189','','0','cart_no_products','В корзине нет товаров','There are no products in the cart','У кошику немає товарів'),
('190','','0','new_password','Новый пароль','New password','Новий пароль'),
('191','','0','on_the_site','на сайте','on the site','на сайті'),
('192','','0','email_password_reply','был сделан запрос на восстановление вашего пароля.','a request was made to recover your password.','був зроблений запит на відновлення вашого пароля.'),
('193','','0','email_password_change','Вы можете изменить пароль, перейдя по следующей ссылке','You can change your password by following the link below','Ви можете змінити пароль, перейшовши за наступним посиланням'),
('194','','0','email_password_text','Эта ссылка действует в течение нескольких минут. <br> Если это письмо пришло вам по ошибке, проигнорируйте его.','This link is effective for a few minutes. <br> If you received this error in error, ignore it.','Це посилання діє протягом декількох хвилин. <br>  Якщо цей лист прийшло вам помилково, ігноруйте його.'),
('226','','0','email_order_status','Статус заказа','Order status','Статус замовлення'),
('196','','0','not_paid','не оплачен','not paid','не сплачено'),
('197','','0','canceled','отменен','canceled','скасований'),
('198','','0','payment','Оплата','Payment','Оплата'),
('199','','0','you_ordered','Вы заказали','You ordered','Ви замовили'),
('200','','0','status','Статус','Status','Статус'),
('201','','0','status_order_link','Вы всегда можете проверить состояние заказа по ссылке:','You can always check the status of your order by following the link:','Ви завжди можете перевірити стан замовлення за посиланням:'),
('202','','0','compare','Сравнение','Compare','Порівняння'),
('203','','0','compare_no_products','Нет товаров для сравнения','There are no products to compare','Немає товарів для порівняння'),
('204','','0','no_brands_found','Бренды не найдены','No brands found','Бренди не знайдені'),
('205','','0','no_articles_found','Статьи не найдены','No articles found','Статті не знайдені'),
('206','','0','popular_categories','Популярные категории','Popular Categories','Популярні категорії'),
('207','','0','bestsellers','Хиты продаж','Bestsellers','Хіти продажів'),
('208','','0','empty_trash','Очистить корзину','Empty trash','Очистити кошик'),
('209','','0','products_from_category','Товары той же категории','Products from category','Товари тієї ж категорії'),
('210','','0','products_from_brand','Товары того же бренда','Products from brand','Товари того ж бренду'),
('211','','0','see_all','Посмотреть все','See all','Переглянути всі'),
('212','','0','captcha','Капча','Captcha','Капча'),
('214','','0','fast_order','Быстрый заказ','Fast order','Швидке замовлення'),
('215','','0','weight','Вес','Weight','Вага'),
('216','','0','email_order_heading','Спасибо за ваш заказ','Thanks for your order','Дякуємо за ваше замовлення'),
('217','','0','email_comment_hello','Здравствуйте,','Hello,','Вітаємо,'),
('218','','0','email_order_message','Сообщаем вам, что вашему заказу','We inform you that your order','Повідомляємо вам, що ваше замовлення'),
('219','','0','email_from','от','of','від'),
('220','','0','email_order_text_status','присвоен статуc','assigned status','присвоєно статуc'),
('221','','0','email_order_button','Перейти к заказу','Go to order','Перейти до замовлення'),
('222','','0','email_order_number','Номер заказа','Order number','Номер замовлення'),
('223','','0','general_payment','Оплата','Payment','Оплата'),
('224','','0','password_remind_title','Восстановление пароля','Password recovery','Відновлення пароля'),
('225','','0','option','Вариант','Option','Варіант'),
('227','','0','contact_us','Связаться с нами','To contact us','Зв\'язатися з нами'),
('228','','0','license_is_invalid','Лицензия недействительна','License is invalid','Ліцензія є недійсною'),
('230','','0','reviews_global','Отзывы','Reviews','Відгуки'),
('231','','0','voice','голос','voice','голос'),
('232','','0','comment_3','Комментария','Comment','Коментаря'),
('233','','0','heading','Рубрика','Heading','Рубрика'),
('234','','0','comment','Комментарий','Comment','Коментар'),
('235','','0','quick_view','Быстрый просмотр','Quick view','Швидкий перегляд'),
('236','','0','general_all','Все','All','Всі'),
('237','','0','next','Вперёд','Next','Вперед'),
('238','','0','previous','Назад','Prev','Назад');

/* Data for table t_users */
TRUNCATE TABLE `t_users`;

/* Data for table t_variants */
TRUNCATE TABLE `t_variants`;

